# Add your edited videos here

### Add an MP4 file

1. Export your finished video as an MP4 (H.264 is a widely compatible choice).
2. Copy it into this folder. For example: `videos/my-reel.mp4`.
3. Open `../portfolio-videos.js` and copy the MP4 example entry into the list.
4. Change the title, category, description, and `file` path to match your video.
5. Save, refresh `index.html`, and check the video controls.

### Use a YouTube or Vimeo player instead

Copy the hosted video's embed URL into `embedUrl`, and its normal public watch URL into `shareUrl`. The embed URL displays the player; the watch URL is what the Share button sends or copies. Keep the video public or unlisted only if you are comfortable with anyone who has the link being able to view it.

Keep only work you have permission to share here. Large video files can make a website slow and may exceed GitHub's file-size limits; use an embeddable video host for larger work. Publish the site before sharing links so clients can open them online.
