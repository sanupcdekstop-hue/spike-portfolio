# SPIKE portfolio

This is a beginner-editable static website. The homepage is `index.html`; it uses plain HTML, CSS, and JavaScript and has no paid service or build step. It does not show prices. The video gallery starts empty and displays only videos you add, so it won't imply that sample work is yours.

## Run it

Open `index.html` in a browser to preview it. To publish for free with GitHub Pages:

1. Sign in to GitHub and create a **public** repository, for example `spike-portfolio`.
2. Upload the contents of this `SPIKE-Portfolio` folder to the repository's top level. Make sure `index.html`, `portfolio-videos.js`, and the `videos` folder are at the repository root level (not inside an extra nested folder).
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/(root)`, then click **Save**.
6. Wait for the Pages deployment to finish. GitHub displays the published link in the Pages settings. A project site usually uses `https://YOUR-USERNAME.github.io/REPOSITORY/`.
7. Open the published link and check it on your phone and computer. Changes you upload to the selected branch are published there too.

GitHub Pages is available for public repositories on GitHub Free. The site is public to everyone, so review all text and videos before uploading. These steps follow [GitHub's Pages publishing instructions](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site); GitHub also documents [uploading files or folders through the browser](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository).

Before publishing, check the contact links and any project details you want public. Do not put private client materials or personal data on the public site. GitHub Pages makes the site public.

## Editing basics

- Change page copy directly in `index.html`.
- To add an MP4, copy it into `videos/`, then add an entry to `portfolio-videos.js`. The cards include playback controls and a Share button. The button uses your device's share sheet when available; otherwise it copies the public video URL for pasting into Discord. An optional hosted-video example is also in that file. See `videos/README.md` for the steps.
- The site cannot post to Discord by itself. Publish the site and video first, then use **Share video** to share or copy its link; paste it into your Discord server's `#portfolio` channel. The **Open SPIKE Discord** button takes people to your invitation. Avoid posting private or client-restricted work publicly.
- Contact links use the supplied Instagram profile, WhatsApp number, and Discord invitation. WhatsApp enquiry links use the international number without `+` or spaces.
- No enquiry form is included: the contact buttons open working channels instead of pretending to submit data.

## Discord setup plan

This is a suggested structure, not a claim that the server has been configured.

**INFORMATION**

- `#welcome` — welcome message and links to services, portfolio, and enquiry instructions.
- `#announcements` — occasional updates from the owner; members read-only.
- `#services` — current services and starting-price note.
- `#portfolio` — finished work and concept studies clearly identified as concepts.
- `#pricing` — optional; use it only if you later decide to share your pricing publicly.
- `#rules` — short rules (template below).

**COMMUNITY**

- `#general`, `#showcase`, `#feedback`, `#suggestions`

**CLIENT AREA**

- `#client-support`, `#project-enquiries`
- General voice and Client meeting voice

Keep client-only discussion private: create a private channel per active client or project and grant access only to the owner and that client. Don't ask people to post phone numbers, raw footage, passwords, payment information, or private briefs in public channels.

**Suggested roles:** `Owner` (all server management), `Moderator` (limited moderation), `Client` (client-only spaces), and `Community Member` (basic participation). Grant only the permissions each role needs. Keep administrator access limited to the owner.

### Copy-ready messages

**Welcome**

> Welcome to SPIKE — a small creative space for video editing and straightforward web design. Browse `#services` and `#portfolio`, and use `#project-enquiries` to tell us what you need. For private project details, contact SPIKE directly through the links on the portfolio site. Please keep personal information and client files out of public channels.

**Rules**

> 1. Be respectful; no harassment, hate, spam, or unsolicited promotion.
> 2. Share only work and files you have permission to post.
> 3. Keep feedback constructive and on-topic.
> 4. Don't post personal contact details, passwords, payment data, or private client information in public channels.
> 5. Project enquiries belong in `#project-enquiries`; share only the basics there and move private details to a direct conversation.
> 6. Follow Discord's Terms and Community Guidelines. Moderators may remove content or restrict access when needed to protect the community.

**Services note**

> SPIKE offers Reels and Shorts editing, YouTube video editing, product ads, promotional videos, basic one-page website design, and small website updates. Message SPIKE with your idea and timeline to discuss the scope and next steps.

**Enquiry prompt**

> Please share: (1) service you're interested in, (2) a short description of what you need, (3) your target date, and (4) relevant public references. Don't attach sensitive files or personal data in a public channel. SPIKE will follow up privately if more detail is needed.

**Portfolio announcement**

> New work added to the SPIKE portfolio: [project name]. [One sentence about the edit or design.] This is [a client project shared with permission / a personal concept study]. Feedback is welcome in `#feedback`.

## Before you publish / manual steps

1. Add your own finished edits in `videos/` and `portfolio-videos.js`; share only work you have permission to show.
2. Verify the contact links and decide whether your phone number should be public on a static site.
3. Create/configure the Discord channels and roles yourself using the plan above. I have not changed the Discord server.
4. Publish only after you review the public copy, links, and video sizes. No domain purchase or paid hosting is needed for GitHub Pages.

## Checks performed

Static checks passed for HTML parsing, JavaScript syntax, section links, the six requested services, supplied contact destinations, safe external-link attributes, absence of price tags, and relative video paths. A browser preview was blocked because this environment rejected opening local `file:` pages; preview `index.html` at desktop and mobile widths, and try a video share after publishing at a public HTTPS URL.
